let title = document.querySelector(".title");
let fadeAndMove = [
  {
    opacity: 0,
    transform: `translateY(-20px)`,
  },
  {
    opacity: 1,
    transform: `translateY(0px)`,
  },
];

let timing = {
  duration: 2000,
  easing: "ease-in-out",
};

const titleChange = title.animate(fadeAndMove, timing);
